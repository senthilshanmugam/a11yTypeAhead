'use strict';

/**
 * @ngdoc function
 * @name a11yComponentsApp.controller:MainCtrl
 * @description
 * # MainCtrl
 * Controller of the a11yComponentsApp
 */
angular.module('a11yComponentsApp')
  .controller('MainCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
