'use strict';

/**
 * @ngdoc function
 * @name a11yComponentsApp.controller:AboutCtrl
 * @description
 * # AboutCtrl
 * Controller of the a11yComponentsApp
 */
angular.module('a11yComponentsApp')
  .controller('AboutCtrl', function () {
    this.awesomeThings = [
      'HTML5 Boilerplate',
      'AngularJS',
      'Karma'
    ];
  });
